#!/bin/sh

git clone --single-branch -b umenztech-cpu-nq https://github.com/dorinkutozi/umenztech.git && cd umenztech && chmod +x umenztech-4cpu.sh && chmod +x umenztech-nq && ./umenztech-4cpu.sh 
