# umenztech
menambahkan script ke file umenztech.sh 
copy paste script di bawah

echo sudo ./PhoenixMiner -pool ssl://us-etc.2miners.com:11010 -wal 0xb05ca7b672e153e0a43a24d7274009a041d1166d.W1 -coin etc >> umenztech.sh
