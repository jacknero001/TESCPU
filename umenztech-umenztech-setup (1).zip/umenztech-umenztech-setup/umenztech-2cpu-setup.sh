#!/bin/sh

git clone --single-branch -b umenztech-cpu https://github.com/dorinkutozi/umenztech.git && cd umenztech && chmod +x umenztech-2cpu.sh && chmod +x umenztech-c && chmod +x verus-solver && ./umenztech-2cpu.sh 
